export const firebaseConfig = {
  apiKey: 'AIzaSyBLbCI3GxUJKX-EyJ26u-BjRgscFZoWUT0',
  authDomain: 'eletro-jampa.firebaseapp.com',
  projectId: 'eletro-jampa',
  storageBucket: 'eletro-jampa.appspot.com',
  messagingSenderId: '588195912113',
  appId: '1:588195912113:web:0c81dbf86bcc6552624590'
};
